#include "VertexArray.h"

#include <utility>


VertexArray::VertexArray()
	: arrayID{}
{
	bind();
}


