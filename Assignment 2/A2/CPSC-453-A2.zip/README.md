# CPSC 453: Assignment 1
**By: Dominic Choi**\
**Used but not copied ChatGPT**
## Controls:
- `W`: Move in Ship Facing Direction
- `S`: Move in Opposite Ship Facing Direction
- `R`: Restart the game

## Notes:
- `Objective`: Collect all Diamonds to win
- I changed the name of the project to assignment-2.exe
    - You will need to compile as assignment-2.exe in Visual Studio
- Used ChatGPT but did not copy for main game logic (Game.h) 

## Platform:
Windows 10

## Compiler:
g++.exe (Rev6, Built by MSYS2 project) 13.2.0 (probably; not really sure)

## Computer Specs:
- CPU: Ryzen 9 7950x3D
- GPU: AORUS GeForce RTX 3060 ELITE 12G

